#!/bin/bash
directorios() {
    echo "funcion directirios"
}