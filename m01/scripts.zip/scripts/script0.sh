#!/bin/bash

while true; do
    echo "MENÚ PRINCIPAL:"    
    echo "1) Crear conjunto de directorios"   
    echo "2) Comprobar exixtencia y mostrar detalles"
    echo "3) Cambiar"
    echo "0) Salir"
    read -p "Seleccione una opción: " opcion

    case $opcion in
        1)
            bash script1.sh
            directorios
            echo "Opción no válida. Intente de nuevo."
            ;;
    esac

    read -p "Presione Enter para continuar..."
done
